from fastapi import FastAPI, HTTPException, Depends, status, Query, Request, UploadFile, File
import shutil, uuid as _uuid, pathlib
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, or_
from datetime import datetime, timedelta, timezone
import os
from typing import List, Optional

from database import get_db
from app.models.academic import SchoolYear, Section, Subject
from models import Staff, StaffDevice, OTPCode, PasswordReset, AuditLog, ClassSchedule
from schemas import (
    StaffRegisterRequest, StaffLoginRequest, TokenResponse, OTPVerifyRequest,
    ForgotPasswordRequest, ResetPasswordRequest, ChangePasswordRequest,
    StaffResponse, AuditLogResponse, ClassScheduleCreate, ClassScheduleUpdate, 
    ClassScheduleResponse
)
from auth import (
    verify_password, get_password_hash, create_access_token,
    create_refresh_token, generate_otp, check_password_reset_lockout,
    validate_password_strength
)
from dependencies import get_current_user, get_current_admin, get_current_user_from_refresh
from pydantic import BaseModel, field_validator
from app.api.routers import school_years, grade_levels, sections, teacher_assignments, subjects, students, student_enrollments, student_pace, schedules, teacher_availabilities, data_quality_logs

from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from database import Base, async_engine
from models import *

app = FastAPI(title="LBCA API", version="1.0.0")

# Serve uploaded profile pictures at /uploads/...
# Ensure upload dirs exist before mounting
pathlib.Path("uploads/profile_pics").mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")

@app.on_event("startup")
async def startup():
    async with async_engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

allowed_origins = [
    "http://localhost:5173",
    "http://localhost:5174",
    "http://localhost:5177",
    "http://127.0.0.1:5173",
    "http://127.0.0.1:5174",
]

extra = os.getenv("ALLOWED_ORIGINS", "")
if extra:
    allowed_origins += [o.strip() for o in extra.split(",")]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ==================== LOCKOUT POLICY ====================

LOCKOUT_MINUTES = [30, 60, 120, 240, 480]  # duration per lockout tier
MAX_ATTEMPTS    = 3                         # wrong passwords before a lockout
MAX_LOCKOUTS    = len(LOCKOUT_MINUTES)      # 5 lockouts → permanent lock


# ==================== INLINE SCHEMAS ====================

class UserStatusUpdate(BaseModel):
    account_status:   str                   # "approved" | "rejected" | "active"
    rejection_reason: Optional[str] = None

class PasswordUpdate(BaseModel):
    password:                 str
    requires_password_change: bool = True

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return validate_password_strength(v)

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password:     str
    confirm_password: str

    @field_validator("new_password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        return validate_password_strength(v)


class UpdateProfileRequest(BaseModel):
    first_name:     str
    last_name:      str
    middle_name:    Optional[str] = None
    email:          str
    contact_number: str


# ==================== HELPER ====================

async def write_audit(
    db: AsyncSession,
    admin_id,
    target_user_id,
    action: str,
    detail: str = None,
):
    """Insert one audit log row."""
    db.add(AuditLog(
        admin_id=admin_id,
        target_user_id=target_user_id,
        action=action,
        detail=detail,
    ))
    # caller is responsible for db.commit()


# ==============================================================
# TABLE 1 — staff
# POST   /api/users              — register (public)
# GET    /api/users              — list all users (admin)
# GET    /api/users/me           — own profile (authenticated)
# PATCH  /api/users/me           — change own password (authenticated)
# PATCH  /api/users/{id}         — approve / reject / reactivate / force-reset (admin)
# DELETE /api/users/{id}         — soft-delete / deactivate (admin)
# GET    /api/users/audit-logs   — view audit log (admin)
# ==============================================================


@app.post("/api/users", status_code=status.HTTP_201_CREATED, tags=["Public"])
async def register(staff_data: StaffRegisterRequest, db: AsyncSession = Depends(get_db)):
    """Public self-registration — creates a pending staff account."""
    result = await db.execute(select(Staff).where(Staff.email == staff_data.email))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    new_staff = Staff(
        email=staff_data.email,
        password_hash=get_password_hash(staff_data.password),
        first_name=staff_data.first_name,
        last_name=staff_data.last_name,
        middle_name=staff_data.middle_name,
        contact_number=staff_data.contact_number,
        role="teacher",
        account_status="pending",
        is_approved=False,
    )
    db.add(new_staff)
    await db.commit()
    await db.refresh(new_staff)
    return {"message": "Registration successful. Awaiting admin approval.", "user_id": str(new_staff.id)}


@app.get("/api/users", response_model=List[StaffResponse], tags=["Admin"])
async def list_users(
    account_status: Optional[str] = Query(None),
    current_user: Staff = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Admin — list all staff, optionally filtered by ?account_status=pending."""
    query = select(Staff)
    if account_status:
        query = query.where(Staff.account_status == account_status)
    result = await db.execute(query)
    return result.scalars().all()


@app.get("/api/users/me", response_model=StaffResponse, tags=["Profile"])
async def get_own_profile(current_user: Staff = Depends(get_current_user)):
    """Authenticated user — fetch own profile."""
    return current_user


@app.get("/api/users/admin-profile", tags=["Profile"])
async def get_admin_profile(
    current_user: Staff = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Any authenticated user — fetch the admin's photo and name for the sidebar."""
    result = await db.execute(
        select(Staff).where(Staff.role == "admin", Staff.is_active == True).limit(1)
    )
    admin = result.scalar_one_or_none()
    if not admin:
        return {"profile_pic": None, "first_name": "", "last_name": ""}
    return {
        "profile_pic": admin.profile_pic,
        "first_name":  admin.first_name,
        "last_name":   admin.last_name,
    }

@app.patch("/api/users/me", tags=["Profile"])
async def change_own_password(
    request: ChangePasswordRequest,
    current_user: Staff = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Authenticated user — change own password."""
    if request.new_password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")
    if not verify_password(request.current_password, current_user.password_hash):
        raise HTTPException(status_code=401, detail="Current password is incorrect")

    current_user.password_hash = get_password_hash(request.new_password)
    current_user.requires_password_change = False
    await db.commit()
    return {"message": "Password changed successfully"}


@app.put("/api/users/me/profile", response_model=StaffResponse, tags=["Profile"])
async def update_own_profile(
    body: UpdateProfileRequest,
    current_user: Staff = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Authenticated user — update own personal info (name, email, contact)."""
    # Check email uniqueness if it changed
    if body.email != current_user.email:
        result = await db.execute(select(Staff).where(Staff.email == body.email))
        if result.scalar_one_or_none():
            raise HTTPException(status_code=400, detail="Email already in use by another account")

    current_user.first_name     = body.first_name.strip()
    current_user.last_name      = body.last_name.strip()
    current_user.middle_name    = body.middle_name.strip() if body.middle_name else None
    current_user.email          = body.email.strip()
    current_user.contact_number = body.contact_number.strip()
    await db.commit()
    await db.refresh(current_user)
    return current_user


# Where uploaded profile pictures are stored (relative to the working directory)
UPLOAD_DIR = pathlib.Path("uploads/profile_pics")

ALLOWED_IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}
MAX_UPLOAD_BYTES    = 5 * 1024 * 1024  # 5 MB


@app.post("/api/users/me/profile-pic", response_model=StaffResponse, tags=["Profile"])
async def upload_profile_pic(
    file: UploadFile = File(...),
    current_user: Staff = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Authenticated user — upload / replace own profile picture."""
    if file.content_type not in ALLOWED_IMAGE_TYPES:
        raise HTTPException(status_code=400, detail="Only JPEG, PNG, GIF, and WebP images are allowed")

    # Read file into memory so we can check size before writing to disk
    data = await file.read()
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=400, detail="File must be smaller than 5 MB")

    ext      = pathlib.Path(file.filename).suffix or ".jpg"
    filename = f"{_uuid.uuid4().hex}{ext}"
    dest     = UPLOAD_DIR / filename

    with open(dest, "wb") as out:
        out.write(data)

    # Delete old picture file if it was stored locally
    if current_user.profile_pic and current_user.profile_pic.startswith("/uploads/"):
        old_path = pathlib.Path(current_user.profile_pic.lstrip("/"))
        if old_path.exists():
            old_path.unlink(missing_ok=True)

    # Store as a URL path the frontend can fetch
    current_user.profile_pic = f"/uploads/profile_pics/{filename}"
    await db.commit()
    await db.refresh(current_user)
    return current_user



@app.patch("/api/users/{user_id}", tags=["Admin"])
async def update_user(
    user_id: str,
    body: UserStatusUpdate | PasswordUpdate,
    current_user: Staff = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """
    Admin — update a user record.
    • Send { password }        to force-reset password (also clears any lock).
    • Send { account_status }  to approve / reject / reactivate.
    """
    result = await db.execute(select(Staff).where(Staff.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")

    if isinstance(body, PasswordUpdate):
        target.password_hash             = get_password_hash(body.password)
        target.requires_password_change  = body.requires_password_change
        target.login_attempts            = 0
        target.locked_until              = None
        target.lockout_count             = 0
        target.permanent_lock            = False
        await write_audit(
            db, current_user.id, target.id,
            action="force_reset_password",
            detail=f"requires_password_change={body.requires_password_change}",
        )
        await db.commit()
        return {"message": f"Password updated for {target.email}. All lockouts cleared."}

    # UserStatusUpdate path
    if body.account_status == "approved":
        target.is_approved    = True
        target.account_status = "approved"
        target.is_active      = True
        target.approved_at    = datetime.now(timezone.utc)
        target.approved_by    = current_user.id
        await write_audit(db, current_user.id, target.id, action="approve_user")

    elif body.account_status == "rejected":
        if not body.rejection_reason:
            raise HTTPException(status_code=400, detail="rejection_reason is required")
        target.account_status   = "rejected"
        target.rejection_reason = body.rejection_reason
        target.is_approved      = False
        target.is_active        = False
        await write_audit(
            db, current_user.id, target.id,
            action="reject_user",
            detail=body.rejection_reason,
        )

    elif body.account_status == "active":
        if target.is_active:
            raise HTTPException(status_code=400, detail="User is already active")
        target.is_active      = True
        target.account_status = "approved"
        await write_audit(db, current_user.id, target.id, action="reactivate_user")

    else:
        raise HTTPException(status_code=400, detail="Invalid account_status value")

    await db.commit()
    await db.refresh(target)
    return target


@app.delete("/api/users/{user_id}", status_code=status.HTTP_204_NO_CONTENT, tags=["Admin"])
async def deactivate_user(
    user_id: str,
    current_user: Staff = Depends(get_current_admin),
    db: AsyncSession = Depends(get_db),
):
    """Admin — soft-delete (mark inactive)."""
    result = await db.execute(select(Staff).where(Staff.id == user_id))
    target = result.scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if str(target.id) == str(current_user.id):
        raise HTTPException(status_code=400, detail="Cannot deactivate your own account")

    target.is_active      = False
    target.account_status = "inactive"
    await write_audit(db, current_user.id, target.id, action="deactivate_user")
    await db.commit()


@app.get("/api/users/audit-logs", response_model=List[AuditLogResponse], tags=["Admin"])
async def get_audit_logs(
    target_user_id: Optional[str] = Query(None, description="Filter by the user the action was performed on"),
    action:         Optional[str] = Query(None, description="Filter by action type"),
    current_user:   Staff = Depends(get_current_admin),
    db:             AsyncSession = Depends(get_db),
):
    """
    Admin — view audit logs.
    Optionally filter by ?target_user_id=... or ?action=approve_user etc.
    Results are ordered newest first.
    """
    query = select(AuditLog).order_by(AuditLog.created_at.desc())
    if target_user_id:
        query = query.where(AuditLog.target_user_id == target_user_id)
    if action:
        query = query.where(AuditLog.action == action)
    result = await db.execute(query)
    return result.scalars().all()


# ==============================================================
# TABLE 2 — sessions
# POST   /api/sessions     — login (create session)
# PUT    /api/sessions/me  — refresh tokens (requires REFRESH token)
# DELETE /api/sessions/me  — logout
# ==============================================================

@app.post("/api/sessions", response_model=TokenResponse, status_code=status.HTTP_201_CREATED, tags=["Authentication"])
async def login(login_data: StaffLoginRequest, db: AsyncSession = Depends(get_db)):
    """Create a session (login). Returns tokens or signals that 2FA is required."""
    result = await db.execute(select(Staff).where(Staff.email == login_data.email))
    staff  = result.scalar_one_or_none()

    if not staff:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    # ── permanent lock ─────────────────────────────────────────────────────────
    if staff.permanent_lock:
        raise HTTPException(
            status_code=403,
            detail="Account permanently locked due to too many failed attempts. Contact your administrator."
        )

    # ── temporary lockout ──────────────────────────────────────────────────────
    if staff.locked_until and staff.locked_until > datetime.now(timezone.utc):
        remaining     = int((staff.locked_until - datetime.now(timezone.utc)).total_seconds() // 60)
        next_duration = LOCKOUT_MINUTES[min(staff.lockout_count, MAX_LOCKOUTS - 1)]
        raise HTTPException(
            status_code=401,
            detail=f"Account locked. Try again in {remaining} minute(s). "
                   f"Warning: next lockout will be {next_duration} minutes."
        )

    # ── approval check ─────────────────────────────────────────────────────────
    if not staff.is_approved:
        raise HTTPException(status_code=403, detail="Account pending admin approval")

    # ── wrong password ─────────────────────────────────────────────────────────
    if not verify_password(login_data.password, staff.password_hash):
        staff.login_attempts += 1

        if staff.login_attempts >= MAX_ATTEMPTS:
            staff.lockout_count += 1

            if staff.lockout_count >= MAX_LOCKOUTS:
                staff.permanent_lock  = True
                staff.login_attempts  = 0
                staff.locked_until    = None
                await db.commit()
                raise HTTPException(
                    status_code=403,
                    detail="Account permanently locked due to too many failed attempts. Contact your administrator."
                )

            duration             = LOCKOUT_MINUTES[staff.lockout_count - 1]
            staff.locked_until   = datetime.now(timezone.utc) + timedelta(minutes=duration)
            staff.login_attempts = 0
            await db.commit()
            raise HTTPException(
                status_code=401,
                detail=f"Too many failed attempts. Account locked for {duration} minutes "
                       f"(lockout {staff.lockout_count}/{MAX_LOCKOUTS})."
            )

        await db.commit()
        attempts_left = MAX_ATTEMPTS - staff.login_attempts
        raise HTTPException(
            status_code=401,
            detail=f"Invalid credentials. {attempts_left} attempt(s) remaining before lockout."
        )

    # ── successful login — reset all lockout state ─────────────────────────────
    staff.login_attempts = 0
    staff.locked_until   = None
    staff.lockout_count  = 0
    await db.commit()

    # ── device / 2FA check ─────────────────────────────────────────────────────
    result = await db.execute(
        select(StaffDevice).where(
            StaffDevice.staff_id == staff.id,
            StaffDevice.device_id == login_data.device_id,
            StaffDevice.is_trusted == True,
        )
    )
    device = result.scalar_one_or_none()

    requires_2fa = not device
    if device and device.last_2fa_verified:
        days_since = (datetime.now(timezone.utc) - device.last_2fa_verified).days
        if days_since >= int(os.getenv("TWO_FACTOR_DAYS_INTERVAL", 90)):
            requires_2fa = True

    if requires_2fa:
        otp_code   = generate_otp()
        expires_at = datetime.now(timezone.utc) + timedelta(
            minutes=int(os.getenv("OTP_EXPIRY_MINUTES", 10))
        )
        db.add(OTPCode(staff_id=staff.id, code=otp_code, purpose="login", expires_at=expires_at))
        await db.commit()
        print(f"OTP for {staff.email}: {otp_code}", flush=True)
        debug_otp_enabled = os.getenv("DEBUG_OTP", "false").lower() in ("1", "true", "yes")
        return TokenResponse(
            requires_2fa=True,
            user_id=str(staff.id),
            debug_otp=otp_code if debug_otp_enabled else None,
        )

    access_token  = create_access_token({"sub": str(staff.id)})
    refresh_token = create_refresh_token({"sub": str(staff.id)})
    expires_at    = datetime.now(timezone.utc) + timedelta(
        minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30))
    )

    if not device:
        device = StaffDevice(
            staff_id=staff.id,
            device_id=login_data.device_id,
            device_name=login_data.device_name,
            is_trusted=True,
            last_2fa_verified=datetime.now(timezone.utc),
        )
        db.add(device)
        await db.flush()

    from models import Session as StaffSession
    db.add(StaffSession(
        staff_id=staff.id,
        device_id=device.id,
        access_token=access_token,
        refresh_token=refresh_token,
        expires_at=expires_at,
    ))
    await db.commit()
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@app.put("/api/sessions/me", response_model=TokenResponse, tags=["Authentication"])
async def refresh_session(
    user_and_session: tuple = Depends(get_current_user_from_refresh),
    db: AsyncSession = Depends(get_db),
):
    """
    Replace session tokens.
    IMPORTANT: Send the REFRESH token in the Authorization header here,
    not the access token.
    """
    current_user, session = user_and_session

    access_token  = create_access_token({"sub": str(current_user.id)})
    refresh_token = create_refresh_token({"sub": str(current_user.id)})
    expires_at    = datetime.now(timezone.utc) + timedelta(
        minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30))
    )
    session.access_token  = access_token
    session.refresh_token = refresh_token
    session.expires_at    = expires_at
    await db.commit()
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


@app.delete("/api/sessions/me", status_code=status.HTTP_204_NO_CONTENT, tags=["Authentication"])
async def logout(
    current_user: Staff = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Invalidate all active sessions (logout)."""
    from models import Session as StaffSession

    result = await db.execute(
        select(StaffSession).where(
            StaffSession.staff_id == current_user.id,
            StaffSession.is_active == True,
        )
    )
    for session in result.scalars().all():
        session.is_active = False
    await db.commit()


# ==============================================================
# TABLE 3 — otp_codes
# POST  /api/otp  — verify login OTP and complete session creation
# ==============================================================

@app.post("/api/otp", response_model=TokenResponse, status_code=status.HTTP_201_CREATED, tags=["Authentication"])
async def verify_otp(verify_data: OTPVerifyRequest, db: AsyncSession = Depends(get_db)):
    """Verify a login OTP and issue tokens (completes 2FA login)."""
    result = await db.execute(
        select(OTPCode).where(
            OTPCode.staff_id == verify_data.user_id,
            OTPCode.code == verify_data.code,
            OTPCode.purpose == "login",
            OTPCode.is_used == False,
            OTPCode.expires_at > datetime.now(timezone.utc),
        )
    )
    otp = result.scalar_one_or_none()
    if not otp:
        raise HTTPException(status_code=401, detail="Invalid or expired OTP")

    otp.is_used = True
    await db.commit()

    result = await db.execute(
        select(StaffDevice).where(
            StaffDevice.staff_id == verify_data.user_id,
            StaffDevice.device_id == verify_data.device_id,
        )
    )
    device = result.scalar_one_or_none()

    if device:
        device.last_used         = datetime.now(timezone.utc)
        device.last_2fa_verified = datetime.now(timezone.utc)
    else:
        device = StaffDevice(
            staff_id=verify_data.user_id,
            device_id=verify_data.device_id,
            device_name=verify_data.device_name,
            is_trusted=True,
            last_2fa_verified=datetime.now(timezone.utc),
        )
        db.add(device)
        await db.flush()

    result = await db.execute(select(Staff).where(Staff.id == verify_data.user_id))
    staff  = result.scalar_one()

    access_token  = create_access_token({"sub": str(staff.id)})
    refresh_token = create_refresh_token({"sub": str(staff.id)})
    expires_at    = datetime.now(timezone.utc) + timedelta(
        minutes=int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", 30))
    )

    from models import Session as StaffSession
    db.add(StaffSession(
        staff_id=staff.id,
        device_id=device.id,
        access_token=access_token,
        refresh_token=refresh_token,
        expires_at=expires_at,
    ))
    await db.commit()
    return TokenResponse(access_token=access_token, refresh_token=refresh_token)


# ==============================================================
# TABLE 4 — password_resets
# POST   /api/password-reset  — request OTP (forgot password)
# PATCH  /api/password-reset  — verify OTP and apply new password
# ==============================================================

@app.post("/api/password-reset", status_code=status.HTTP_202_ACCEPTED, tags=["Password Reset"])
async def request_password_reset(request: ForgotPasswordRequest, db: AsyncSession = Depends(get_db)):
    """Send a password-reset OTP to the user's registered contact."""
    result = await db.execute(select(Staff).where(Staff.email == request.email))
    staff  = result.scalar_one_or_none()

    if not staff:
        return {"message": "If that email exists, an OTP will be sent"}

    result       = await db.execute(select(PasswordReset).where(PasswordReset.staff_id == staff.id))
    reset_record = result.scalar_one_or_none()

    if not reset_record:
        reset_record = PasswordReset(staff_id=staff.id)
        db.add(reset_record)
        await db.commit()
        await db.refresh(reset_record)

    if check_password_reset_lockout(reset_record):
        remaining = (reset_record.locked_until - datetime.now(timezone.utc)).seconds // 60
        raise HTTPException(status_code=429, detail=f"Too many attempts. Try again in {remaining} minutes")

    if reset_record.window_start:
        hours_since = (datetime.now(timezone.utc) - reset_record.window_start).total_seconds() / 3600
        if hours_since > 24:
            reset_record.request_count = 1
            reset_record.window_start  = datetime.now(timezone.utc)
        else:
            reset_record.request_count += 1

    max_attempts = int(os.getenv("MAX_PASSWORD_RESET_ATTEMPTS", 3))
    if reset_record.request_count > max_attempts:
        reset_record.locked_until = datetime.now(timezone.utc) + timedelta(
            hours=24
        )
        await db.commit()
        raise HTTPException(status_code=429, detail="Too many attempts. Try again in 30 minutes")

    await db.commit()

    otp_code   = generate_otp()
    expires_at = datetime.now(timezone.utc) + timedelta(minutes=int(os.getenv("OTP_EXPIRY_MINUTES", 10)))
    otp = OTPCode(
        staff_id=staff.id,
        code=otp_code,
        purpose="password_reset",
        expires_at=expires_at,
    )
    db.add(otp)
    await db.commit()
    await db.refresh(otp)

    print(f"PASSWORD RESET OTP for {staff.email}: {otp_code}", flush=True)
    return {"message": "OTP sent to your email/phone"}


@app.patch("/api/password-reset", tags=["Password Reset"])
async def apply_password_reset(request: ResetPasswordRequest, db: AsyncSession = Depends(get_db), tags=["Password Reset"]):
    """Verify OTP token and set the new password."""
    if request.new_password != request.confirm_password:
        raise HTTPException(status_code=400, detail="Passwords do not match")

    result = await db.execute(
        select(OTPCode).where(
            OTPCode.code == request.token,
            OTPCode.purpose == "password_reset",
            OTPCode.is_used == False,
            OTPCode.expires_at > datetime.now(timezone.utc),
        )
    )
    otp = result.scalar_one_or_none()
    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    result = await db.execute(select(Staff).where(Staff.id == otp.staff_id))
    staff  = result.scalar_one()

    staff.password_hash            = get_password_hash(request.new_password)
    staff.requires_password_change = False
    staff.login_attempts           = 0
    staff.locked_until             = None
    staff.lockout_count            = 0
    staff.permanent_lock           = False
    otp.is_used = True

    result       = await db.execute(select(PasswordReset).where(PasswordReset.staff_id == staff.id))
    reset_record = result.scalar_one_or_none()
    if reset_record:
        reset_record.request_count = 0
        reset_record.window_start  = None
        reset_record.locked_until  = None
        reset_record.reset_token   = None
        reset_record.token_expires = None

    await db.commit()
    return {"message": "Password reset successful. You can now login."}

@app.post("/api/password-reset/validate-otp", tags=["Password Reset"])
async def validate_reset_otp(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Validate password reset OTP before showing password form."""
    body = await request.json()
    email = body.get("email")
    code = body.get("code")
    
    if not email or not code:
        raise HTTPException(status_code=400, detail="Email and code are required")
    
    # Find user
    result = await db.execute(select(Staff).where(Staff.email == email))
    staff = result.scalar_one_or_none()
    
    if not staff:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Find valid OTP
    result = await db.execute(
        select(OTPCode).where(
            OTPCode.staff_id == staff.id,
            OTPCode.code == code,
            OTPCode.purpose == "password_reset",
            OTPCode.is_used == False,
            OTPCode.expires_at > datetime.now(timezone.utc),
        )
    )
    otp = result.scalar_one_or_none()
    
    if not otp:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")
    
    return {"valid": True, "message": "OTP verified successfully"}

# ==============================================================
# CLASS SCHEDULES - Simplified (no enrichment)
# ==============================================================

@app.get("/api/class-schedules/")
async def list_class_schedules(
    school_year_id: Optional[int] = Query(None),
    section_id: Optional[int] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: Staff = Depends(get_current_user),
):
    """List all class schedules"""
    try:
        query = select(ClassSchedule)
        
        if school_year_id:
            query = query.where(ClassSchedule.school_year_id == school_year_id)
        if section_id:
            query = query.where(ClassSchedule.section_id == section_id)
        
        result = await db.execute(query)
        schedules = result.scalars().all()
        
        response = []
        for schedule in schedules:
            # Get teacher name
            teacher_result = await db.execute(select(Staff).where(Staff.id == schedule.teacher_id))
            teacher = teacher_result.scalar_one_or_none()
            
            response.append({
                "id": schedule.id,
                "school_year_id": schedule.school_year_id,
                "section_id": schedule.section_id,
                "subject_id": schedule.subject_id,
                "teacher_id": str(schedule.teacher_id),
                "teacher_name": f"{teacher.first_name} {teacher.last_name}" if teacher else "Unknown",
                "day_of_week": schedule.day_of_week,
                "start_time": schedule.start_time,
                "end_time": schedule.end_time,
                "room": schedule.room,
                "created_at": schedule.created_at,
                "updated_at": schedule.updated_at,
            })
        
        return response
    except Exception as e:
        print(f"Error: {e}")
        return []

@app.put("/api/class-schedules/{schedule_id}")
async def update_class_schedule(
    schedule_id: int,
    data: ClassScheduleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: Staff = Depends(get_current_admin),
):
    """Update an existing class schedule"""
    try:
        result = await db.execute(
            select(ClassSchedule).where(ClassSchedule.id == schedule_id)
        )
        schedule = result.scalar_one_or_none()
        if not schedule:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        # Update fields
        if data.school_year_id is not None:
            schedule.school_year_id = data.school_year_id
        if data.section_id is not None:
            schedule.section_id = data.section_id
        if data.subject_id is not None:
            schedule.subject_id = data.subject_id
        if data.teacher_id is not None:
            schedule.teacher_id = uuid.UUID(data.teacher_id)
        if data.day_of_week is not None:
            schedule.day_of_week = data.day_of_week
        if data.start_time is not None:
            schedule.start_time = data.start_time
        if data.end_time is not None:
            schedule.end_time = data.end_time
        if data.room is not None:
            schedule.room = data.room
        
        schedule.updated_at = datetime.now(timezone.utc)
        
        await db.commit()
        await db.refresh(schedule)
        
        return {"message": "Schedule updated successfully", "id": schedule.id}
    except Exception as e:
        print(f"Error updating schedule: {e}")
        await db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
        
@app.post("/api/class-schedules", status_code=status.HTTP_201_CREATED)
async def create_class_schedule(
    data: ClassScheduleCreate,
    db: AsyncSession = Depends(get_db),
    current_user: Staff = Depends(get_current_admin),
):
    """Create a new class schedule"""
    try:
        # Verify teacher exists
        teacher_result = await db.execute(select(Staff).where(Staff.id == _uuid.UUID(data.teacher_id)))
        if not teacher_result.scalar_one_or_none():
            raise HTTPException(status_code=404, detail="Teacher not found")
        
        schedule = ClassSchedule(
            school_year_id=data.school_year_id,
            section_id=data.section_id,
            subject_id=data.subject_id,
            teacher_id=_uuid.UUID(data.teacher_id),
            day_of_week=data.day_of_week,
            start_time=data.start_time,
            end_time=data.end_time,
            room=data.room,
        )
        db.add(schedule)
        await db.commit()
        await db.refresh(schedule)
        
        return {"message": "Schedule created successfully", "id": schedule.id}
    except Exception as e:
        print(f"Error creating schedule: {e}")
        await db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@app.patch("/api/class-schedules/{schedule_id}")
async def update_class_schedule(
    schedule_id: int,
    data: ClassScheduleUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: Staff = Depends(get_current_admin),
):
    """Update an existing class schedule"""
    try:
        result = await db.execute(
            select(ClassSchedule).where(ClassSchedule.id == schedule_id)
        )
        schedule = result.scalar_one_or_none()
        if not schedule:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        # Update only provided fields
        if data.school_year_id is not None:
            schedule.school_year_id = data.school_year_id
        if data.section_id is not None:
            schedule.section_id = data.section_id
        if data.subject_id is not None:
            schedule.subject_id = data.subject_id
        if data.teacher_id is not None:
            # Verify teacher exists
            teacher_result = await db.execute(select(Staff).where(Staff.id == _uuid.UUID(data.teacher_id)))
            if not teacher_result.scalar_one_or_none():
                raise HTTPException(status_code=404, detail="Teacher not found")
            schedule.teacher_id = _uuid.UUID(data.teacher_id)
        if data.day_of_week is not None:
            schedule.day_of_week = data.day_of_week
        if data.start_time is not None:
            schedule.start_time = data.start_time
        if data.end_time is not None:
            schedule.end_time = data.end_time
        if data.room is not None:
            schedule.room = data.room
        
        await db.commit()
        await db.refresh(schedule)
        
        return {"message": "Schedule updated successfully", "id": schedule.id}
    except Exception as e:
        print(f"Error updating schedule: {e}")
        await db.rollback()
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/api/class-schedules/{schedule_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_class_schedule(
    schedule_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: Staff = Depends(get_current_admin),
):
    """Delete a class schedule"""
    try:
        result = await db.execute(
            select(ClassSchedule).where(ClassSchedule.id == schedule_id)
        )
        schedule = result.scalar_one_or_none()
        if not schedule:
            raise HTTPException(status_code=404, detail="Schedule not found")
        
        await db.delete(schedule)
        await db.commit()
    except Exception as e:
        print(f"Error deleting schedule: {e}")
        await db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
        
# ==============================================================
# TABLE 5 — staff_devices
# Managed internally by /api/sessions and /api/otp.
# No direct public endpoint needed.
# ==============================================================

# Academic module routers
app.include_router(school_years.router)
app.include_router(grade_levels.router)
app.include_router(sections.router)
app.include_router(teacher_assignments.router)

from app.api.routers import students, student_enrollments, student_pace
app.include_router(students.router)
app.include_router(student_enrollments.router)
app.include_router(student_pace.router)

from app.api.routers import subjects, schedules, teacher_availabilities, data_quality_logs
app.include_router(subjects.router)
app.include_router(schedules.router)
app.include_router(teacher_availabilities.router)
app.include_router(data_quality_logs.router)